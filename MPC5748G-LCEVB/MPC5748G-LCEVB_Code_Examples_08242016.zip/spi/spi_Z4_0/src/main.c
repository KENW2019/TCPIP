/*****************************************************************************/
/* FILE NAME: main.c	              COPYRIGHT (c) NXP Semiconductors 2016  */
/*                                                      All Rights Reserved  */
/* PLATFORM: MPC5748G-LCEVB													 */
/* DESCRIPTION: Main C program for core 0 (e200z4a) to call SPI  functions   */
/*				Configures DSPI_0 in Master mode and SPI_4 in slave mode.	 */
/*				Master continuously sends data to Slave and Slave replies	 */
/* 				to master.													 */
/*                                                                           */
/*				DSPI_0 Pin Mapping:			SPI_4 Pin Mapping				 */
/*				CLK	  	PA14				CLK 	PF2						 */
/*				SOUT  	PA13				SOUT	PF0						 */
/*				SIN	  	PA12				SIN		PF1						 */
/*				SS/CS0	PA15				SS/CS0	PF3						 */
/*****************************************************************************/
/* REV      AUTHOR        DATE        DESCRIPTION OF CHANGE                  */
/* ---   -----------    ----------    ---------------------                  */
/* 1.0	 Scott Obrien   21 Apr 2015   Initial Version                        */
/* 1.1	 K Shah			16 Mar 2016	  Ported to S32DS						 */
/*****************************************************************************/

#include "derivative.h" /* include peripheral declarations */
#include "project.h"
#include "spi.h"
#include "mode.h"

#define KEY_VALUE1 0x5AF0ul
#define KEY_VALUE2 0xA50Ful

extern void xcptn_xmpl(void);
void peri_clock_gating (void); /* Configures gating/enabling peripheral(DSPI, SPI) clocks */

void hw_init(void)
{
#if defined(DEBUG_SECONDARY_CORES)
	uint32_t mctl = MC_ME.MCTL.R;
#if defined(TURN_ON_CPU1)
	/* enable core 1 in all modes */
	MC_ME.CCTL[2].R = 0x00FE;
	/* Set Start address for core 1: Will reset and start */
	MC_ME.CADDR[2].R = 0x11d0000 | 0x1;
#endif
#if defined(TURN_ON_CPU2)
	/* enable core 2 in all modes */
	MC_ME.CCTL[3].R = 0x00FE;
	/* Set Start address for core 2: Will reset and start */
	MC_ME.CADDR[3].R = 0x13a0000 | 0x1;
#endif
	MC_ME.MCTL.R = (mctl & 0xffff0000ul) | KEY_VALUE1;
	MC_ME.MCTL.R =  mctl; /* key value 2 always from MCTL */
#endif /* defined(DEBUG_SECONDARY_CORES) */
}

__attribute__ ((section(".text")))

/************************************ Main ***********************************/

int main(void)
{
	unsigned int i = 0;

	xcptn_xmpl ();              			  /* Configure and Enable Interrupts */

    peri_clock_gating();                      /* Configures gating/enabling peripheral(DSPI, SPI) clocks for modes*/
	                                          /* Configuration occurs after mode transition */
	system160mhz();                           /* sysclk=160MHz, dividers configured, mode trans*/

	init_DSPI_0();                            /* Initialize DSPI_0 as master SPI and initialize CTAR0 */
	init_SPI_4();                             /* Initialize SPI_4 as Slave SPI and initialize CTAR0 */
	init_spi_ports();                         /* DSPI_0 Master, SPI_4 Slave */

	while( 1 )
	{
	  SPI_4.PUSHR.PUSHR.R = 0x00001234;       /* Initialize slave SPI_4's response to master */
	  DSPI_0.PUSHR.PUSHR.R  = 0x08015678;     /* Transmit data from master DSPI_0 to slave SPI with EOQ */
	  read_data_SPI_4();                      /* Read data on slave SPI */
	  read_data_DSPI_0();                     /* Read data on master DSPI */
	  i++;
	}
	return 0;
}

/************************  End of Main ***************************************/

void peri_clock_gating (void) {		/* Configures gating/enabling peripheral(DSPI, SPI) clocks */

  MC_ME.RUN_PC[0].R = 0x00000000;  	/* Gate off clock for all RUN modes */
  MC_ME.RUN_PC[1].R = 0x000000FE;  	/* Configures peripheral clock for all RUN modes */
  MC_ME.PCTL[40].B.RUN_CFG = 0x1;  	/* DSPI_0: select peripheral configuration RUN_PC[1] */
  MC_ME.PCTL[100].B.RUN_CFG = 0x1;  /* SPI_4: select peripheral configuration RUN_PC[1] */
}
