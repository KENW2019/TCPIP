/*****************************************************************************/
/* FILE NAME: spi.c                    COPYRIGHT (c) NXP Semiconductors 2016 */
/*                                                      All Rights Reserved  */
/* PLATFORM: MPC5748G-LCEVB													 */
/* DESCRIPTION: SPI functions for initialization and reading received data.  */
/*                                                                           */
/*****************************************************************************/	
/* REV      AUTHOR        DATE        DESCRIPTION OF CHANGE                  */
/* ---   -----------    ----------    ---------------------                  */
/* 1.0	 Scott Obrien   21 Apr 2015   Initial Version                        */
/* 1.0	 K Shah		    16 Mar 2016   Ported to S32DS                        */
/*****************************************************************************/

#include "project.h"
#include "spi.h"

void init_spi_ports() {
  /* Master - DSPI_0 */
  SIUL2.MSCR[PA13].B.SSS = 1;               /* Pad PA13: Source signal is DSPI_0 SOUT  */
  SIUL2.MSCR[PA13].B.OBE = 1;               /* Pad PA13: OBE=1. */
  SIUL2.MSCR[PA13].B.SRC = 3;               /* Pad PA13: Full strength slew rate */
  
  SIUL2.MSCR[PA14].B.SSS = 1;				/* Pad PA14: Source signal is DSPI_0 CLK  */
  SIUL2.MSCR[PA14].B.OBE = 1;            	/* Pad PA14: OBE=1. */
  SIUL2.MSCR[PA14].B.SRC = 3;               /* Pad PA14: Full strength slew rate */
  
  SIUL2.MSCR[PA12].B.IBE = 1;              	/* Pad PA12: Enable pad for input DSPI_0 SIN */
  SIUL2.IMCR[288].B.SSS = 1;     	        /* Pad PA12: connected to pad PG5 */

  SIUL2.MSCR[PA15].B.SSS = 1;               /* Pad PA15: Source signal is DSPI_0 CS0  */
  SIUL2.MSCR[PA15].B.OBE = 1;               /* Pad PA15: OBE=1. */
  SIUL2.MSCR[PA15].B.SRC = 3;               /* Pad PA15: Full strength slew rate */
  
  /* Slave - SPI_4 */
  SIUL2.MSCR[PF2].B.SSS = 1;                /* Pad PF2: Source signal is SPI_4 CLK */
  SIUL2.MSCR[PF2].B.IBE = 1;                /* Pad PF2: IBE=1. */
  SIUL2.IMCR[313].B.SSS = 1;            	/* Pad PF2: SPI_4 CLK */
  
  SIUL2.MSCR[PF0].B.SSS = 3;                /* Pad PF0: Source signal is SPI_4 SOUT */
  SIUL2.MSCR[PF0].B.OBE = 1;                /* Pad PF0: OBE=1. */
  SIUL2.MSCR[PF0].B.SRC = 3;                /* Pad PF0: Full strength slew rate */
  
  SIUL2.MSCR[PF1].B.IBE = 1;                /* Pad PF1: Enable pad for input SPI_4 SIN */
  SIUL2.IMCR[312].B.SSS = 1;	            /* Pad PF1: connected to pad */

  SIUL2.MSCR[PF3].B.IBE = 1;                /* Pad PF3: IBE=1. SPI_4 SS */
  SIUL2.IMCR[314].B.SSS = 1;            	/* Pad PF3: connected to pad */
}

/*****************************************************************************/

void init_dspi_0(void)
{
  DSPI_0.MCR.R = 0x80010001;                /* Configure DSPI_0 as master */
  DSPI_0.MODE.CTAR[0].R = 0xB8001111;       /* Configure CTAR0 : Fast as possible : 20MHz : 3 Delays REQUIRED */
  DSPI_0.RSER.R = 0x03000000;               /* Enable DMA for TX */
}

void init_spi_4(void)
{
  SPI_4.MCR.R = 0x00010001;                 /* Configure SPI_4 as slave */
  SPI_4.MODE.CTAR[0].R = 0x38000000;        /* Configure CTAR0 : 8 Bit  */
  SPI_4.RSER.R = 0x00030000;                /* Enable DMA for RX */
  SPI_4.MCR.B.HALT = 0x0;                   /* Exit HALT mode: go from STOPPED to RUNNING state*/
  SPI_4.SR.R = 0xFCFE0000;                  /* Clear ALL status flags by writing 1 */
}

/*****************************************************************************/
