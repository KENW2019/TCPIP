#ifndef _SPI_H
#define _SPI_H

#include "project.h"

void init_spi_ports(void);
void init_dspi_0 (void);
void init_spi_4 (void);

#endif /* _SPI_H */
