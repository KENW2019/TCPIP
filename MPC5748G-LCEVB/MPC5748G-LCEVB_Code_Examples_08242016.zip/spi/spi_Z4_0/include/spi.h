#ifndef _SPI_H
#define _SPI_H

#include "project.h"

void init_spi_ports(void);
void init_DSPI_0 (void);
void read_data_DSPI_0 (void);
void init_SPI_4 (void);
void read_data_SPI_4 (void);

#endif /* _SPI_H */
