/*
 * smpu.h
 *
 *  Created on: Apr 5, 2016
 *      Author: B55457
 */

#ifndef SMPU_H_
#define SMPU_H_

#include "derivative.h"

void initSMPU();

#endif /* SMPU_H_ */
